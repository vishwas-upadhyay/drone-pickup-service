package com.vishwas.depottocustomerdeliverytime;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class DepotToCustomerDeliveryTimeApplication {

	public static void main(String[] args) {
		SpringApplication.run(DepotToCustomerDeliveryTimeApplication.class, args);
	}
}
